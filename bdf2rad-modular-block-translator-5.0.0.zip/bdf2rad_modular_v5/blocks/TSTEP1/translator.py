from bdf2rad.core.types import RadBlock
from bdf2rad.core.formatting import bdf_time_to_rad_ms

def translate(model,ctx,plugin):
    # The runnable engine seed already contains /RUN/{{RUNNAME}}/1. This plugin supplies only its exact Tstop field.
    tid=int(model.case.get('TSTEP','0') or 0);t=model.tsteps.get(tid)
    tstop=bdf_time_to_rad_ms(t.dt) if t else 3.0
    return [RadBlock('__ENGINE_METADATA__',[f'{tstop:.12g}'],910,plugin.name,plugin.source_cards)],[{'card':'TSTEP1','status':'translated','target':'/RUN/{{RUNNAME}}/1','Tstop_ms':tstop}]
