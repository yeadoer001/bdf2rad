from __future__ import annotations
from pathlib import Path
import json

def _load_header(root: Path, kind: str):
    data=json.loads((root/'knowledge_base'/'header_seed.json').read_text(encoding='utf-8'))
    return list(data[kind])

def _apply_seed_identity(lines, job, tstop=None):
    out=[]
    for line in lines:
        s=line.replace('{{RUNNAME}}',job).replace('{{TITLE}}',f'{job} Converted from Nastran BDF')
        if tstop is not None: s=s.replace('{{TSTOP}}',str(tstop))
        out.append(s)
    return out

def assemble_starter(root: Path, job: str, blocks):
    header=_apply_seed_identity(_load_header(root,'starter'),job)
    body=[]
    for b in sorted((x for x in blocks if x.order < 900),key=lambda x:(x.order,x.plugin,x.keyword)):
        body.extend(b.lines)
    return header+body+['/END']

def assemble_engine(root: Path, job: str, blocks):
    import json
    tstop=None
    for b in blocks:
        if b.plugin=='tstep1' and b.lines:
            try: tstop=b.lines[0]
            except Exception: pass
    header=_apply_seed_identity(_load_header(root,'engine'),job,tstop)
    body=[]
    for b in sorted(blocks,key=lambda x:(x.order,x.plugin,x.keyword)):
        if b.keyword=='__ENGINE_METADATA__':
            continue
        body.extend(b.lines)
    return header+body
